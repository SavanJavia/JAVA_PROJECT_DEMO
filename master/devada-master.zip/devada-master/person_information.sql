
INSERT INTO `person_information` (`birth_date`, `blood_group`, `education`, `father_name`, `is_approved`, `mobile`, `mosan`, `mother_name`, `name`, `permanent_address`, `phone`, `present_address`, `vas`, `work`, `password`, `username`, `role`) VALUES
(NULL, NULL, NULL, NULL, 'Y', '8365874590', NULL, NULL, 'admin', NULL, NULL, NULL, NULL, NULL, 'admin', 'admin', 'admin'),
('21/21/5214', 'a+', 'education', 'father name', '1', '965214785', 'mosan', 'mother name', 'general user', 'address', '958745', 'add', 'vas', 'job', 'pwd', 'user1', 'guser');
