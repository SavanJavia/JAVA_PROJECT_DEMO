package com.devada.base.enumeration;

public enum ResponseMessageType {
  SUCCESS, ERROR, VALIDATION, BATCH,

}
