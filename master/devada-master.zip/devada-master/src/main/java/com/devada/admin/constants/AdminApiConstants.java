package com.devada.admin.constants;

public interface AdminApiConstants {

  String ADD_CATEGORY = "/add_category";
  String GET_CATEGORY = "/get_category";
  String DELETE_CATEGORY = "/delete_category";
  String CREATE_EVENT = "/create_event";
  String SAVE_EVENT = "/save_event";
}
