package com.devada.admin.api.dao;

import com.devada.admin.api.entity.MarriedDaughter;
import com.devada.base.dao.BaseDao;

public interface MarriedDaughterDao extends BaseDao<MarriedDaughter, Integer> {
}
