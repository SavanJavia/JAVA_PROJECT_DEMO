package com.devada.admin.api.dao;

import com.devada.admin.api.entity.FamilyInformation;
import com.devada.admin.api.entity.PersonInformation;
import com.devada.base.dao.BaseDao;

public interface FamilyInformationDao extends BaseDao<FamilyInformation, Integer> {
}
