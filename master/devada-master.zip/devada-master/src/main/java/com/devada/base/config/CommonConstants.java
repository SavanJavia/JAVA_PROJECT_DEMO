package com.devada.base.config;

public interface CommonConstants {
  int ZERO_VALUE = 0;
  int ONE_VALUE = 1;
}
