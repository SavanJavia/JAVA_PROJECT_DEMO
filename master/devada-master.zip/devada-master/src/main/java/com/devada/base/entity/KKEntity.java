package com.devada.base.entity;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class KKEntity implements Serializable {

  private static final long serialVersionUID = 1L;

}
